#!/bin/sh
#
#!
# @file jni/src/harmony/generic/0.0/clean.sh
#
# @brief Remove build of sample JNI subset, showing how to reference
#              the local native methods, but using the full
#              JNI mechanism.
#
# @see @link jni/src/harmony/generic/0.0/build.sh
#            jni/src/harmony/generic/0.0/build.sh@endlink
#
# @see @link jni/src/harmony/generic/0.0/common.sh
#            jni/src/harmony/generic/0.0/common.sh@endlink
#
# @see @link ./build.sh ./build.sh@endlink
#
# @see @link ./clean.sh ./clean.sh@endlink
#
# @see @link ./common.sh ./common.sh@endlink
#
#
# @todo  HARMONY-6-jni-clean.sh-1 A Windows .BAT version of this
#        script needs to be written
#
#
# @section Control
#
# \$URL: https://svn.apache.org/repos/asf/incubator/harmony/enhanced/trunk/sandbox/contribs/bootjvm/bootJVM/jni/src/harmony/generic/0.0/clean.sh $
#
# \$Id: clean.sh 326503 2005-10-19 09:33:12Z dlydick $
#
# Copyright 2005 The Apache Software Foundation
# or its licensors, as applicable.
#
# Licensed under the Apache License, Version 2.0 ("the License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied.
#
# See the License for the specific language governing permissions
# and limitations under the License.
#
# @version \$LastChangedRevision: 326503 $
#
# @date \$LastChangedDate: 2005-10-19 04:33:12 -0500 (Wed, 19 Oct 2005) $
#
# @author \$LastChangedBy: dlydick $
#
#         Original code contributed by Daniel Lydick on 09/28/2005.
#
# @section Reference
#
#/ /* 
# (Use  #! and #/ with dox_filter.sh to fool Doxygen into
# parsing this non-source text file for the documentation set.
# Use the above open comment to force termination of parsing
# since it is not a Doxygen-style 'C' comment.)
#
#
###################################################################
#
# Script setup
#
. common.sh

###################################################################
#
# Remove output area.
#
chmod -R +w $TARGET_DIRECTORY
rm -rf $TARGET_DIRECTORY
rc=$?

###################################################################
#
# Done.
#
exit $rc

#
# EOF
