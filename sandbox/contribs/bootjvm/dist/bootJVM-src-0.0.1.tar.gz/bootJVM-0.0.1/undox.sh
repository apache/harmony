#!/bin/sh
#!
# @file ./undox.sh
#
# @brief Remove project documentation created by @b doxygen.
#
# Simply remove the documenation directory.
#
#
# @todo  HARMONY-6-undox.sh-1 A Windows .BAT version of this
#        script needs to be written
#
#
# @section Control
#
# \$URL: https://svn.apache.org/repos/asf/incubator/harmony/enhanced/trunk/sandbox/contribs/bootjvm/bootJVM/undox.sh $
#
# \$Id: undox.sh 326513 2005-10-19 09:47:54Z dlydick $
#
# Copyright 2005 The Apache Software Foundation
# or its licensors, as applicable.
#
# Licensed under the Apache License, Version 2.0 ("the License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied.
#
# See the License for the specific language governing permissions
# and limitations under the License.
#
# @version \$LastChangedRevision: 326513 $
#
# @date \$LastChangedDate: 2005-10-19 04:47:54 -0500 (Wed, 19 Oct 2005) $
#
# @author \$LastChangedBy: dlydick $
#
#         Original code contributed by Daniel Lydick on 09/28/2005.
#
# @section Reference
#
#/ /* 
# (Use  #! and #/ with dox_filter.sh to fool Doxygen into
# parsing this non-source text file for the documentation set.
# Use the above open comment to force termination of parsing
# since it is not a Doxygen-style 'C' comment.)
#
#
########################################################################
#
# Script setup
#
. commondox.sh

########################################################################
#
# Remove output directory, clean up its subdirectories for results
#
$RMALL_CMD
rc=$?

exit $rc
#
# EOF
